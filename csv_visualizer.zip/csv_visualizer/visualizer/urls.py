from django.urls import path
from . import views

urlpatterns = [
    path('', views.upload_csv, name='upload_csv'),
    path('visualize/<int:file_id>/', views.visualize_data, name='visualize'),
]