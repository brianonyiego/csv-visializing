import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from .models import CSVFile
from .forms import CSVFileForm

ACCEPTABLE_FILES = [
    "Kilometres_travelled_by_mode_of_transport.csv",
    "Greenhouse_gas_emissions_profile_by_sector.csv",
    "Greenhouse_gas_emissions_by_modes_of_transport.csv"
]


def upload_csv(request):
    if request.method == 'POST':
        form = CSVFileForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.cleaned_data['file']
            if file.name in ACCEPTABLE_FILES:
                csv_file = CSVFile(file=file, name=file.name)
                csv_file.save()
                return redirect('visualize', file_id=csv_file.id)
            else:
                form.add_error('file', f"The file '{file.name}' is not a valid file.")
    else:
        form = CSVFileForm()
    return render(request, 'visualizer/upload.html', {'form': form})


def visualize_data(request, file_id):
    csv_file = CSVFile.objects.get(id=file_id)
    file_path = os.path.join(settings.MEDIA_ROOT, str(csv_file.file))
    df = pd.read_csv(file_path)

    image_files = []

    if csv_file.name == "Kilometres_travelled_by_mode_of_transport.csv":
        image_files = [
            'kilometres_line_plot.png',
            'kilometres_bar_plot.png',
            'kilometres_bicycle_vs_bus.png',
            'kilometres_cumulative.png'
        ]
        generate_kilometres_visualizations(df)
    elif csv_file.name == "Greenhouse_gas_emissions_profile_by_sector.csv":
        image_files = [
            'emissions_profile_line_plot.png',
            'emissions_profile_bar_plot.png',
            'emissions_profile_acc_vs_comm.png',
            'emissions_profile_cumulative.png'
        ]
        generate_emissions_profile_visualizations(df)
    elif csv_file.name == "Greenhouse_gas_emissions_by_modes_of_transport.csv":
        image_files = [
            'emissions_modes_line_plot.png',
            'emissions_modes_bar_plot.png',
            'emissions_modes_cumulative.png'
        ]
        generate_emissions_modes_visualizations(df)

    context = {
        'file_name': csv_file.name,
        'image_files': image_files,
        'MEDIA_URL': settings.MEDIA_URL,  # Add this line
    }


    if csv_file.name == "Kilometres_travelled_by_mode_of_transport.csv":
        generate_kilometres_visualizations(df)
    elif csv_file.name == "Greenhouse_gas_emissions_profile_by_sector.csv":
        generate_emissions_profile_visualizations(df)
    elif csv_file.name == "Greenhouse_gas_emissions_by_modes_of_transport.csv":
        generate_emissions_modes_visualizations(df)

    return render(request, 'visualizer/visualize.html', context)

def generate_kilometres_visualizations(df):
    years = df.columns[1:-1]  # Skip 'Data_Type' and 'ObjectId'
    readable_years = [year.replace('F', '') for year in years]

    sns.set(style="whitegrid")

    # 1. Line Plot for All Modes Over Time
    plt.figure(figsize=(10, 6))
    for i, row in df.iterrows():
        plt.plot(readable_years, row[1:-1], label=row['Data_Type'])
    plt.title("Kilometers Traveled by Mode of Transport Over Time")
    plt.xlabel("Years")
    plt.ylabel("Kilometers Traveled")
    plt.xticks(rotation=45)
    plt.legend(title="Mode of Transport")
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'kilometres_line_plot.png'))
    plt.close()

    # 2. Bar Plot for Kilometers Traveled in 2018/19
    plt.figure(figsize=(8, 6))
    sns.barplot(x=df['Data_Type'], y=df['F2018_19'])
    plt.title("Kilometers Traveled by Mode in 2018/19")
    plt.xlabel("Mode of Transport")
    plt.ylabel("Kilometers Traveled")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'kilometres_bar_plot.png'))
    plt.close()

    # 3. Line Plot for Bicycle vs Bus Comparison Over Time
    plt.figure(figsize=(10, 6))
    bicycle_data = df[df['Data_Type'].str.contains("Bicycle")].iloc[0, 1:-1]
    bus_data = df[df['Data_Type'].str.contains("Bus")].iloc[0, 1:-1]
    plt.plot(readable_years, bicycle_data, label="Bicycle", marker="o")
    plt.plot(readable_years, bus_data, label="Bus", marker="o")
    plt.title("Comparison: Kilometers Traveled by Bicycle vs Bus Over Time")
    plt.xlabel("Years")
    plt.ylabel("Kilometers Traveled")
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'kilometres_bicycle_vs_bus.png'))
    plt.close()

    # 4. Cumulative Kilometers Traveled Over the Entire Period
    df['Cumulative'] = df[years].sum(axis=1)
    plt.figure(figsize=(8, 6))
    sns.barplot(x=df['Data_Type'], y=df['Cumulative'])
    plt.title("Cumulative Kilometers Traveled by Mode (2005-2019)")
    plt.xlabel("Mode of Transport")
    plt.ylabel("Total Kilometers Traveled")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'kilometres_cumulative.png'))
    plt.close()


def generate_emissions_profile_visualizations(df):
    years = df.columns[3:]  # Skip 'CustomGrouping', 'SectorLevel_2', 'FID'
    readable_years = [year.replace('F', '') for year in years]

    sns.set(style="whitegrid")

    # 1. Line Plot for All Sectors Over Time
    plt.figure(figsize=(10, 6))
    for i, row in df.iterrows():
        plt.plot(readable_years, row[3:], label=row['SectorLevel_2'])
    plt.title("Greenhouse Gas Emissions by Sector Over Time")
    plt.xlabel("Years")
    plt.ylabel("Emissions")
    plt.xticks(rotation=45)
    plt.legend(title="Sector")
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'emissions_profile_line_plot.png'))
    plt.close()

    # 2. Bar Plot for Emissions in 2018/19
    plt.figure(figsize=(8, 6))
    sns.barplot(x=df['SectorLevel_2'], y=df['F2018_19'])
    plt.title("Greenhouse Gas Emissions by Sector in 2018/19")
    plt.xlabel("Sector")
    plt.ylabel("Emissions")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'emissions_profile_bar_plot.png'))
    plt.close()

    # 3. Line Plot for Accommodation vs Commercial Office Over Time
    plt.figure(figsize=(10, 6))
    acc_data = df[df['SectorLevel_2'] == "Non-Residential - Accommodation/Entertainment"].iloc[0, 3:]
    comm_data = df[df['SectorLevel_2'] == "Non-Residential - Commercial Office"].iloc[0, 3:]
    plt.plot(readable_years, acc_data, label="Accommodation/Entertainment", marker="o")
    plt.plot(readable_years, comm_data, label="Commercial Office", marker="o")
    plt.title("Comparison: Emissions by Accommodation vs Commercial Office Over Time")
    plt.xlabel("Years")
    plt.ylabel("Emissions")
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'emissions_profile_acc_vs_comm.png'))
    plt.close()

    # 4. Cumulative Emissions Over the Entire Period
    df['Cumulative'] = df[years].sum(axis=1)
    plt.figure(figsize=(8, 6))
    sns.barplot(x=df['SectorLevel_2'], y=df['Cumulative'])
    plt.title("Cumulative Greenhouse Gas Emissions by Sector (2005-2019)")
    plt.xlabel("Sector")
    plt.ylabel("Total Emissions")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'emissions_profile_cumulative.png'))
    plt.close()


def generate_emissions_modes_visualizations(df):
    years = df.columns[2:-1]  # Skip 'Data_Category', 'Data_Type', and 'ObjectId'
    readable_years = [year.replace('F', '') for year in years]

    sns.set(style="whitegrid")

    # 1. Line Plot for All Modes Over Time
    plt.figure(figsize=(10, 6))
    for i, row in df.iterrows():
        plt.plot(readable_years, row[2:-1], label=row['Data_Type'])
    plt.title("Greenhouse Gas Emissions by Mode of Transport Over Time")
    plt.xlabel("Years")
    plt.ylabel("Emissions")
    plt.xticks(rotation=45)
    plt.legend(title="Mode of Transport")
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'emissions_modes_line_plot.png'))
    plt.close()

    # 2. Bar Plot for Emissions in 2018/19
    plt.figure(figsize=(8, 6))
    sns.barplot(x=df['Data_Type'], y=df['F2018_19'])
    plt.title("Greenhouse Gas Emissions by Mode in 2018/19")
    plt.xlabel("Mode of Transport")
    plt.ylabel("Emissions")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'emissions_modes_bar_plot.png'))
    plt.close()

    # 3. Cumulative Emissions by Mode Over the Entire Period
    df['Cumulative'] = df[years].sum(axis=1)
    plt.figure(figsize=(8, 6))
    sns.barplot(x=df['Data_Type'], y=df['Cumulative'])
    plt.title("Cumulative Greenhouse Gas Emissions by Mode (2005-2019)")
    plt.xlabel("Mode of Transport")
    plt.ylabel("Total Emissions")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'emissions_modes_cumulative.png'))
    plt.close()